#!/bin/sh

#last use of this script copied in files from NF2 SVN rev 3904
#note: OFT_ROOT and NF2_ROOT must be set 
cp $NF2_ROOT/lib/Perl5/Test/* $OFT_ROOT/lib/Perl5/Test/
